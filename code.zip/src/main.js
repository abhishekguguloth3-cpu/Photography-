import './styles.css';

const images = {
  hero: '/manus-storage/async-images/LCmShqFG6iSfHNrLEU9gEB/image-1.webp',
  street: '/manus-storage/async-images/LCmShqFG6iSfHNrLEU9gEB/image-2.webp',
  portrait: '/manus-storage/async-images/LCmShqFG6iSfHNrLEU9gEB/image-3.webp',
  landscape: '/manus-storage/async-images/LCmShqFG6iSfHNrLEU9gEB/image-4.webp'
};

const arrowIcon = '<svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="M5 12h13M13 6l6 6-6 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const plusIcon = '<svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';

const app = document.querySelector('#app');

app.innerHTML = `
  <div class="site-shell">
    <header class="site-header">
      <a class="wordmark" href="#top" aria-label="Abhishek home">
        <span class="wordmark-mark"><span>A</span></span>
        <span>Abhishek</span>
      </a>
      <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-navigation">Menu <span class="menu-dots">•••</span></button>
      <nav id="primary-navigation" class="primary-nav" aria-label="Primary navigation">
        <a href="#work">Work</a>
        <a href="#about">About</a>
        <a href="#contact">Contact <span class="nav-arrow">↗</span></a>
      </nav>
    </header>

    <main id="top">
      <section class="hero section-pad" aria-labelledby="hero-title">
        <div class="hero-copy reveal">
          <div class="eyebrow"><span class="eyebrow-line"></span> Freelance photographer · 2024—Now</div>
          <h1 id="hero-title">Stories<br /><em>in</em> <span>light.</span></h1>
          <p class="hero-intro">I’m Abhishek — a photographer drawn to the honest, in-between moments that make a place or a person feel unforgettable.</p>
          <a class="text-link" href="#work">See selected work ${arrowIcon}</a>
        </div>
        <div class="hero-visual reveal reveal-delay">
          <div class="hero-image-wrap">
            <img src="${images.hero}" alt="Photographer standing on a sunlit coastal cliff" />
            <span class="image-stamp">01 / 04</span>
          </div>
          <div class="hero-caption"><span>Self-portrait, Konkan coast</span><span>14° 32′ N / 74° 18′ E</span></div>
        </div>
        <div class="hero-side-note">Available for selected<br />projects worldwide <span>↓</span></div>
      </section>

      <section id="work" class="work section-pad" aria-labelledby="work-title">
        <div class="section-heading reveal">
          <p class="section-index">01 — Selected work</p>
          <div class="heading-row"><h2 id="work-title">The work<br /><em>between</em> moments.</h2><p class="heading-note">A small edit of portraits, places, and the details that make them human.</p></div>
        </div>
        <div class="work-grid">
          <article class="project project-tall reveal">
            <div class="project-image"><img src="${images.street}" alt="Cyclist crossing a rain-slicked city intersection" loading="lazy" /><span class="project-number">01</span></div>
            <div class="project-meta"><div><h3>After rain</h3><p>Street / Mumbai, 2023</p></div><span class="project-plus">${plusIcon}</span></div>
          </article>
          <article class="project project-wide reveal reveal-delay">
            <div class="project-image"><img src="${images.landscape}" alt="Small figure walking across red desert dunes" loading="lazy" /><span class="project-number">02</span></div>
            <div class="project-meta"><div><h3>Earth, in red</h3><p>Travel / Rajasthan, 2024</p></div><span class="project-plus">${plusIcon}</span></div>
          </article>
          <article class="project project-portrait reveal">
            <div class="project-image"><img src="${images.portrait}" alt="Portrait of a woman against a warm ochre wall" loading="lazy" /><span class="project-number">03</span></div>
            <div class="project-meta"><div><h3>Still, moving</h3><p>Portraits / Bengaluru, 2024</p></div><span class="project-plus">${plusIcon}</span></div>
          </article>
        </div>
        <div class="work-footer reveal"><span>More stories are in the making.</span><a class="text-link" href="#contact">Start a conversation ${arrowIcon}</a></div>
      </section>

      <section id="about" class="about section-pad" aria-labelledby="about-title">
        <div class="about-marker reveal"><span class="section-index">02 — About me</span><span class="marker-arrow">↘</span></div>
        <div class="about-content reveal reveal-delay">
          <h2 id="about-title">The best frames<br />usually happen<br /><em>between</em> the planned ones.</h2>
          <div class="about-body"><p class="about-lead">I photograph people, places, and the quiet energy that connects them.</p><p>My practice lives somewhere between documentary instinct and considered portraiture. I’m interested in the look that arrives before a smile, the color a city keeps after dark, and all the small signals that tell a bigger story.</p><p>Based in India and available wherever the work leads, I collaborate with brands, people, and teams who value a point of view.</p><a class="text-link dark-link" href="#contact">Let’s make something worth remembering ${arrowIcon}</a></div>
        </div>
        <div class="about-stats reveal"><div><strong>08</strong><span>years making<br />pictures</span></div><div><strong>14</strong><span>cities<br />photographed</span></div><div><strong>∞</strong><span>curiosity<br />remaining</span></div></div>
      </section>

      <section id="contact" class="contact section-pad" aria-labelledby="contact-title">
        <div class="contact-heading reveal"><p class="section-index">03 — Contact</p><h2 id="contact-title">Have a story<br /><em>in mind?</em></h2><p>Tell me a little about the project, the feeling, or just say hello. I usually reply within two working days.</p></div>
        <form class="contact-form reveal reveal-delay" novalidate>
          <label><span>Your name</span><input name="name" type="text" autocomplete="name" placeholder="Jane Smith" required /></label>
          <label><span>Email address</span><input name="email" type="email" autocomplete="email" placeholder="jane@studio.com" required /></label>
          <label class="message-field"><span>What are we making?</span><textarea name="message" rows="4" placeholder="A portrait series, a campaign, a place worth seeing…" required></textarea></label>
          <div class="form-footer"><button class="submit-button" type="submit">Send enquiry ${arrowIcon}</button><span class="form-note">No hard sell. Just a good conversation.</span></div>
          <p class="form-status" role="status" aria-live="polite"></p>
        </form>
      </section>
    </main>

    <footer class="site-footer"><div class="footer-top"><span class="footer-wordmark">ABHISHEK<span>®</span></span><span>Personal portfolio / Photography</span><a href="#top">Back to top ↑</a></div><div class="footer-bottom"><span>© 2024 Abhishek. All rights reserved.</span><div><a href="mailto:hello@abhishek.photo">hello@abhishek.photo</a><a href="https://instagram.com" target="_blank" rel="noreferrer">Instagram ↗</a></div></div></footer>
  </div>
`;

const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.primary-nav');
menuToggle.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('is-open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});
nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  nav.classList.remove('is-open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

document.querySelector('.contact-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const status = form.querySelector('.form-status');
  if (!form.checkValidity()) {
    form.classList.add('has-error');
    status.textContent = 'Please fill in your name, email, and a short project note.';
    form.querySelector(':invalid')?.focus();
    return;
  }
  form.classList.remove('has-error');
  status.textContent = 'Thanks — your note is ready to start a conversation with Abhishek.';
  form.reset();
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach((element) => observer.observe(element));
